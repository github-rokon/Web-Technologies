<br><br>
<center>
<a href="about-us.php"><p style="color:black;">About Us</p></a><br>
<p style="color:lack;">"<h3>Copyright 500BC-2024 by DevRashed. All Rights Reserved.</h3></p>
</center>
<br>
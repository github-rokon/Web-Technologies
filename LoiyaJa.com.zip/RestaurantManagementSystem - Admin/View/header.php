<br><br>
<center>
<h1 style="color:LightYellow;font-family:"Lucida Console", monospace;>LoiyaJa.com</h1>
<p style="color:black; font-family:"Times New Roman", serif;>Order your meal and take away 24x7</p>
</center>
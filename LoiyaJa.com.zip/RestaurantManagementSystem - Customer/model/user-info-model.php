<?php

    require_once('database.php');

    $row;

    function login($email, $password){

        global $row;

        $con = dbConnection();
        $sql = $con -> prepare ("select * from UserInfo where email = ? and password = ?");
        $sql -> bind_param("ss", $email, $password);
        $sql -> execute();
        $result = $sql -> get_result();
        $count = mysqli_num_rows($result);

        if($count == 1) 
        {
        $row = mysqli_fetch_assoc($result);
        return $row;
        }
        else return false;

    }

    function addUser($fullname, $phone, $email, $address, $dob, $religion, $username, $password, $role){

        $con = dbConnection();
        $sql = $con -> prepare ("insert into UserInfo values('', ?, ?, ?, ?, ?, ?, ?, ?, 'Uploads/Images/default_pfp.png', ?, 'Active')");
        $sql -> bind_param("sssssssss", $fullname, $phone, $email, $address, $dob, $religion, $username, $password, $role);

        if($sql -> execute()) return true;
        else return false;
        
    }
    
    function uniqueEmail($email){

        $con = dbConnection();
        $sql = $con -> prepare ("select email from userinfo where email = ? ");
        $sql -> bind_param("s", $email);
        $sql -> execute();
        $result = $sql -> get_result();
        $count = mysqli_num_rows($result);

        if($count == 1) return false;
        else return true; 
        
    }

    function getUserByMail($email){

        $con = dbConnection();
        $sql = $con -> prepare ("Select * from UserInfo where Email = ?");
        $sql -> bind_param("s", $email);
        $sql -> execute();
             
        $result = $sql -> get_result();
        $row = mysqli_fetch_assoc($result);
        return $row;
        
    }

    function changePassword($id, $newpass){

        $con=dbConnection();
        $sql = $con -> prepare ("update UserInfo set Password = ? where UserID = ?");
        $sql -> bind_param("ss", $newpass, $id);

        if($sql -> execute()===true) return true;
        else return false; 
        
    }

    function userInfo($id){

        $con=dbConnection();
        $sql="select* from UserInfo where UserID='$id'";

        $result=mysqli_query($con,$sql);
        $row=mysqli_fetch_assoc($result);

        return $row;
        
    }

    function updateProfilePicture($imagename, $id){

        $con = dbConnection();
        $sql = $con -> prepare ("update UserInfo set ProfilePicture = ? where UserID = ?");
        $sql -> bind_param("ss", $imagename, $id);
             
        if($sql -> execute()===true) return true;
        else return false; 
        
    }

    function updateUserInfo($id, $fullname, $email, $phone, $address, $religion, $username){

        $con = dbConnection();
        $sql = $con -> prepare ("update UserInfo set Fullname = ?, Username = ?, Phone = ?, Email = ?, Religion = ?, Address = ? where UserID = ?");
        $sql -> bind_param("sssssss", $fullname, $username, $phone, $email, $religion, $address, $id);

        if($sql -> execute()===true) return true;
        else return false; 
        
    }

    function getAllDeliveryPerson(){

        $con = dbConnection();
        $sql = "select * from UserInfo where Role = 'Delivery Man' and status = 'Active'";

        $result = mysqli_query($con,$sql);
        return $result;

    }

    function getAllCustomer(){

        $con = dbConnection();
        $sql = "select * from UserInfo where Role = 'Customer' and status = 'Active'";

        $result = mysqli_query($con,$sql);
        return $result;

    }

    function getAllManager(){

        $con = dbConnection();
        $sql = "select * from UserInfo where Role = 'Manager' and status = 'Active'";

        $result = mysqli_query($con,$sql);
        return $result;

    }

    function numberOfCustomer(){

        $con = dbConnection();
        $sql = "select * from UserInfo where Role='Customer' and status='Active'";

        $result = mysqli_query($con,$sql);
        return mysqli_num_rows($result);

    }

    function numberOfDeliveryMan(){

        $con = dbConnection();
        $sql = "select * from UserInfo where Role='Delivery Man' and status='Active'";

        $result = mysqli_query($con,$sql);
        return mysqli_num_rows($result);

    }

    function getUsernameByID($id){

        $con = dbConnection();
        $sql = "select Username from UserInfo where UserID = '$id'";

        $result = mysqli_query($con,$sql);
        $row=mysqli_fetch_assoc($result);

        return $row['Username'];

    }

    function banCustomer($id){

        $con = dbConnection();
        $sql = "update UserInfo set status = 'Inactive' where UserID = '$id'";
        $result = mysqli_query($con,$sql);
        
        if($result) return $result;
        else return false;
        
    }

?>